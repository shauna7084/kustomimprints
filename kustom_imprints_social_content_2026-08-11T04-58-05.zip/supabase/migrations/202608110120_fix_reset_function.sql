-- Fix: Supabase enforces safe-updates on DELETE statements, so a bare DELETE fails.
-- Adding WHERE TRUE satisfies the check without changing the behavior.
CREATE OR REPLACE FUNCTION reset_all_calendar_overrides(p_token TEXT)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Verify board token
  IF p_token != (SELECT value FROM app_settings WHERE key = 'board_token') THEN
    RAISE EXCEPTION 'Invalid board token';
  END IF;

  -- Supabase enforces safe-updates on bare DELETE; filter on the non-null PK
  -- to satisfy the check while deleting every row.
  DELETE FROM calendar_overrides WHERE day IS NOT NULL;
END;
$$;
