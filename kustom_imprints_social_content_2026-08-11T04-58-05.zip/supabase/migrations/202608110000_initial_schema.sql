-- Initial schema for the Kustom Imprints shared social calendar.
-- Run this first in a fresh Supabase project, then run the later migrations in order.

-- Shared storage for calendar edits.
CREATE TABLE IF NOT EXISTS calendar_overrides (
  day INTEGER PRIMARY KEY,
  caption TEXT,
  engagement TEXT,
  hashtags TEXT[] DEFAULT '{}',
  deleted BOOLEAN DEFAULT FALSE,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Private board passcode storage.
CREATE TABLE IF NOT EXISTS app_settings (
  key TEXT PRIMARY KEY,
  value TEXT
);

-- Set the default board passcode. Change this to something only your board knows.
INSERT INTO app_settings (key, value)
VALUES ('board_token', 'kustom-pta-board-2026')
ON CONFLICT (key) DO NOTHING;

-- Public read access for the calendar overrides.
ALTER TABLE calendar_overrides ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Allow public read" ON calendar_overrides;
CREATE POLICY "Allow public read"
  ON calendar_overrides
  FOR SELECT
  USING (TRUE);

-- Upsert function. Later migrations will add image columns and update this signature.
CREATE OR REPLACE FUNCTION update_calendar_override(
  p_day INTEGER,
  p_caption TEXT,
  p_engagement TEXT,
  p_hashtags TEXT[],
  p_deleted BOOLEAN,
  p_token TEXT
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF p_token != (SELECT value FROM app_settings WHERE key = 'board_token') THEN
    RAISE EXCEPTION 'Invalid board token';
  END IF;

  INSERT INTO calendar_overrides (
    day, caption, engagement, hashtags, deleted, updated_at
  )
  VALUES (
    p_day, p_caption, p_engagement, p_hashtags, p_deleted, NOW()
  )
  ON CONFLICT (day)
  DO UPDATE SET
    caption = EXCLUDED.caption,
    engagement = EXCLUDED.engagement,
    hashtags = EXCLUDED.hashtags,
    deleted = EXCLUDED.deleted,
    updated_at = NOW();
END;
$$;

-- Reset function. Later migrations will fix the DELETE clause for safe-update mode.
CREATE OR REPLACE FUNCTION reset_all_calendar_overrides(p_token TEXT)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF p_token != (SELECT value FROM app_settings WHERE key = 'board_token') THEN
    RAISE EXCEPTION 'Invalid board token';
  END IF;

  DELETE FROM calendar_overrides WHERE day IS NOT NULL;
END;
$$;
