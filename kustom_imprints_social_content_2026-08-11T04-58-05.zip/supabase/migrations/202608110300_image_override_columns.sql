-- Add image override fields to the calendar overrides table.
-- This enables the UI to swap single images and add multiple images to carousel posts.

ALTER TABLE calendar_overrides
  ADD COLUMN IF NOT EXISTS image TEXT,
  ADD COLUMN IF NOT EXISTS images TEXT[];

-- Update the override upsert function to accept and persist the new image fields.
CREATE OR REPLACE FUNCTION update_calendar_override(
  p_day INTEGER,
  p_caption TEXT,
  p_engagement TEXT,
  p_hashtags TEXT[],
  p_deleted BOOLEAN,
  p_token TEXT,
  p_image TEXT DEFAULT NULL,
  p_images TEXT[] DEFAULT NULL
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF p_token != (SELECT value FROM app_settings WHERE key = 'board_token') THEN
    RAISE EXCEPTION 'Invalid board token';
  END IF;

  INSERT INTO calendar_overrides (
    day, caption, engagement, hashtags, deleted, image, images, updated_at
  )
  VALUES (
    p_day, p_caption, p_engagement, p_hashtags, p_deleted, p_image, p_images, now()
  )
  ON CONFLICT (day)
  DO UPDATE SET
    caption = EXCLUDED.caption,
    engagement = EXCLUDED.engagement,
    hashtags = EXCLUDED.hashtags,
    deleted = EXCLUDED.deleted,
    image = EXCLUDED.image,
    images = EXCLUDED.images,
    updated_at = now();
END;
$$;
