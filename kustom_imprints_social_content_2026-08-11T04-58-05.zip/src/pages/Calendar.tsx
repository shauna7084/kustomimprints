import { useState, useEffect, useMemo } from 'react';
import { calendarDays, type PostType, type CalendarDay } from '@/data/calendar';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { supabase } from '@/lib/supabase';
import { toast } from 'sonner';
import { ChevronLeft, ChevronRight, Images } from 'lucide-react';

const themeColors: Record<PostType, string> = {
  product: 'bg-[#0a5ca4]',
  lifestyle: 'bg-[#b6d0e5]',
  carousel: 'bg-[#cfcfcf]',
  poll: 'bg-[#826c5f]',
  fundraiser: 'bg-[#524644]',
  clipart: 'bg-[#0a5ca4]',
};

const themeText: Record<PostType, string> = {
  product: 'text-white',
  lifestyle: 'text-[#524644]',
  carousel: 'text-[#524644]',
  poll: 'text-white',
  fundraiser: 'text-white',
  clipart: 'text-white',
};

const BOARD_TOKEN_KEY = 'kustom-board-token';

type Overrides = Record<number, Partial<CalendarDay>>;

function parseHashtags(input: string): string[] {
  return input
    .split(/[\s,]+/)
    .map((t) => t.replace(/^#/, '').trim())
    .filter(Boolean);
}

function formatHashtags(tags: string[]): string {
  return tags.map((t) => `#${t}`).join(' ');
}

function primaryImage(day: CalendarDay): string {
  return day.images?.[0] ?? day.image;
}

function allImages(day: CalendarDay): string[] {
  if (day.images && day.images.length > 0) return day.images;
  return [day.image];
}

export default function Calendar() {
  const [days, setDays] = useState<CalendarDay[]>(() => calendarDays.map((d) => ({ ...d })));
  const [selected, setSelected] = useState<CalendarDay | null>(null);
  const [modalIndex, setModalIndex] = useState(0);
  const [editingDays, setEditingDays] = useState<Record<number, boolean>>({});
  const [draft, setDraft] = useState<Overrides>({});
  const [showDeleted, setShowDeleted] = useState(false);
  const [boardToken, setBoardToken] = useState<string | null>(null);
  const [loginOpen, setLoginOpen] = useState(false);
  const [tokenInput, setTokenInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Load board token and shared overrides on mount.
  useEffect(() => {
    const savedToken = localStorage.getItem(BOARD_TOKEN_KEY);
    if (savedToken) setBoardToken(savedToken);
    loadOverrides();
  }, []);

  useEffect(() => {
    if (selected) setModalIndex(0);
  }, [selected]);

  const loadOverrides = async () => {
    setLoading(true);
    setError(null);
    const { data, error: supaError } = await supabase.from('calendar_overrides').select('*');
    if (supaError) {
      setError('Could not load saved edits. Make sure the Supabase SQL ran.');
      setLoading(false);
      return;
    }
    const overrides: Overrides = {};
    data?.forEach((row: any) => {
      const override: Partial<CalendarDay> = {
        caption: row.caption,
        engagement: row.engagement,
        hashtags: row.hashtags || [],
        deleted: row.deleted,
      };
      if (row.image) override.image = row.image;
      if (row.images && row.images.length > 0) override.images = row.images;
      overrides[row.day] = override;
    });
    setDays(calendarDays.map((d) => ({ ...d, ...(overrides[d.day] || {}) })));
    setLoading(false);
  };

  const visibleDays = useMemo(
    () => days.filter((d) => showDeleted || !d.deleted),
    [days, showDeleted]
  );
  const deletedCount = useMemo(() => days.filter((d) => d.deleted).length, [days]);
  const editingCount = Object.keys(editingDays).length;

  const effectiveDay = (day: CalendarDay): CalendarDay => {
    const draftOverride = draft[day.day];
    return draftOverride ? { ...day, ...draftOverride } : day;
  };

  const saveDay = async (dayNum: number, partial: Partial<CalendarDay>) => {
    if (!boardToken) return;
    const current = days.find((d) => d.day === dayNum) || calendarDays[dayNum - 1];
    const next = { ...current, ...partial } as CalendarDay;
    setError(null);
    const { error: rpcError } = await supabase.rpc('update_calendar_override', {
      p_day: dayNum,
      p_caption: next.caption,
      p_engagement: next.engagement,
      p_hashtags: next.hashtags,
      p_deleted: !!next.deleted,
      p_token: boardToken,
      p_image: next.image || null,
      p_images: next.images || null,
    });
    if (rpcError) {
      setError(rpcError.message || 'Save failed. Check your board token.');
      throw rpcError;
    }
    setDays((prev) => prev.map((d) => (d.day === dayNum ? next : d)));
  };

  const saveAll = async () => {
    if (!boardToken || editingCount === 0) return;
    setError(null);
    const edited = Object.keys(editingDays).map((n) => Number(n));
    try {
      await Promise.all(edited.map((dayNum) => saveDay(dayNum, draft[dayNum])));
      setEditingDays({});
      setDraft({});
      toast.success('All changes saved and synced.');
    } catch (e) {
      toast.error('Some changes failed to save. Check the error message above.');
    }
  };

  const toggleDelete = (dayNum: number) => {
    if (!boardToken) {
      setLoginOpen(true);
      return;
    }
    const day = days.find((d) => d.day === dayNum);
    if (!day) return;
    saveDay(dayNum, { ...day, deleted: !day.deleted });
  };

  const startEdit = (day: CalendarDay) => {
    if (!boardToken) {
      setLoginOpen(true);
      return;
    }
    setEditingDays((prev) => ({ ...prev, [day.day]: true }));
    setDraft((prev) => ({
      ...prev,
      [day.day]: {
        caption: day.caption,
        engagement: day.engagement,
        hashtags: [...day.hashtags],
        image: day.image,
        images: day.images ? [...day.images] : day.type === 'carousel' ? [] : undefined,
      },
    }));
  };

  const cancelEdit = (dayNum: number) => {
    setEditingDays((prev) => {
      const next = { ...prev };
      delete next[dayNum];
      return next;
    });
    setDraft((prev) => {
      const next = { ...prev };
      delete next[dayNum];
      return next;
    });
  };

  const saveEdit = async (dayNum: number) => {
    if (!boardToken) return;
    try {
      await saveDay(dayNum, draft[dayNum]);
      cancelEdit(dayNum);
    } catch {
      // error already surfaced
    }
  };

  const updateDraft = (dayNum: number, patch: Partial<CalendarDay>) => {
    setDraft((prev) => ({
      ...prev,
      [dayNum]: { ...prev[dayNum], ...patch },
    }));
  };

  const updateImage = (dayNum: number, value: string) => {
    updateDraft(dayNum, { image: value.trim() });
  };

  const updateCarouselImage = (dayNum: number, idx: number, value: string) => {
    const current = draft[dayNum]?.images || [];
    const next = [...current];
    next[idx] = value;
    updateDraft(dayNum, { images: next });
  };

  const addCarouselImage = (dayNum: number) => {
    const current = draft[dayNum]?.images || [];
    updateDraft(dayNum, { images: [...current, ''] });
  };

  const removeCarouselImage = (dayNum: number, idx: number) => {
    const current = draft[dayNum]?.images || [];
    const next = current.filter((_, i) => i !== idx);
    updateDraft(dayNum, { images: next });
  };

  const resetAll = async () => {
    if (!boardToken) return;
    setError(null);
    const { error: rpcError } = await supabase.rpc('reset_all_calendar_overrides', {
      p_token: boardToken,
    });
    if (rpcError) {
      setError(rpcError.message);
      return;
    }
    setEditingDays({});
    setDraft({});
    await loadOverrides();
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    localStorage.setItem(BOARD_TOKEN_KEY, tokenInput);
    setBoardToken(tokenInput);
    setLoginOpen(false);
    setTokenInput('');
  };

  const logout = () => {
    localStorage.removeItem(BOARD_TOKEN_KEY);
    setBoardToken(null);
    setEditingDays({});
    setDraft({});
  };

  const renderImageEditor = (day: CalendarDay) => {
    const isCarousel = day.type === 'carousel';
    if (isCarousel) {
      const images = draft[day.day]?.images || [];
      return (
        <div className="flex flex-col gap-2">
          <label className="text-xs font-semibold text-[#826c5f] font-['Open_Sans']">
            Carousel images
          </label>
          {images.map((url, idx) => (
            <div key={idx} className="flex gap-2">
              <Input
                value={url}
                onChange={(e) => updateCarouselImage(day.day, idx, e.target.value)}
                placeholder="https://..."
                className="text-sm font-['Open_Sans']"
              />
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => removeCarouselImage(day.day, idx)}
                className="shrink-0 font-['Open_Sans'] text-xs"
              >
                Remove
              </Button>
            </div>
          ))}
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => addCarouselImage(day.day)}
            className="w-fit font-['Open_Sans'] text-xs"
          >
            Add image
          </Button>
        </div>
      );
    }
    return (
      <div className="flex flex-col gap-1">
        <label className="text-xs font-semibold text-[#826c5f] font-['Open_Sans']">
          Image URL
        </label>
        <Input
          value={draft[day.day]?.image || ''}
          onChange={(e) => updateImage(day.day, e.target.value)}
          placeholder="https://..."
          className="text-sm font-['Open_Sans']"
        />
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-[#f8f6f4] text-[#524644] font-['Open_Sans']">
      <header className="bg-[#0a5ca4] text-white py-12 px-6 text-center font-['Montserrat']">
        <h1 className="text-4xl md:text-5xl font-bold mb-3">Kustom Imprints</h1>
        <p className="text-xl md:text-2xl font-['Open_Sans'] opacity-95">
          120-Day Facebook Social Media Calendar
        </p>
        <p className="text-sm md:text-base font-['Open_Sans'] opacity-80 mt-2">
          Apparel · Drinkware · Fundraiser Content · Clipart | Strict cycle: Product → Lifestyle → Carousel → Poll → Fundraiser → Clipart
        </p>
      </header>

      <section className="max-w-6xl mx-auto px-4 py-8">
        <div className="flex flex-wrap gap-3 mb-6 justify-center font-['Open_Sans'] text-sm">
          {Object.entries(themeColors).map(([type, color]) => (
            <span
              key={type}
              className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-white ${color}`}
            >
              <span className="w-2 h-2 rounded-full bg-white/80" />
              {type === 'clipart' ? 'Clipart / Flat Design' : type.charAt(0).toUpperCase() + type.slice(1)}
            </span>
          ))}
        </div>

        <div className="flex flex-wrap items-center justify-between gap-4 mb-6 p-4 bg-white rounded-xl border border-[#e5e2df]">
          <div className="flex items-center gap-3 flex-wrap">
            {boardToken ? (
              <>
                <Checkbox
                  id="show-deleted"
                  checked={showDeleted}
                  onCheckedChange={(checked) => setShowDeleted(checked === true)}
                />
                <span
                  onClick={() => setShowDeleted((v) => !v)}
                  className="text-sm font-['Open_Sans'] cursor-pointer"
                >
                  Show deleted posts
                </span>
                <span className="text-xs text-[#826c5f] font-['Open_Sans']">
                  {deletedCount} deleted · {visibleDays.length} visible
                </span>
              </>
            ) : (
              <span className="text-sm text-[#826c5f] font-['Open_Sans']">
                Board login required to edit.
              </span>
            )}
          </div>
          <div className="flex items-center gap-3 flex-wrap">
            {loading && <span className="text-xs text-[#826c5f]">Loading…</span>}
            {boardToken ? (
              <>
                <span className="text-xs font-semibold text-[#0a5ca4]">Board mode</span>
                {editingCount > 0 && (
                  <Button
                    size="sm"
                    onClick={saveAll}
                    className="font-['Open_Sans'] text-xs bg-[#0a5ca4] hover:bg-[#094a84]"
                  >
                    Save all edits ({editingCount})
                  </Button>
                )}
                <Button variant="outline" size="sm" onClick={logout} className="font-['Open_Sans'] text-xs">
                  Logout
                </Button>
                <Button variant="outline" size="sm" onClick={resetAll} className="font-['Open_Sans'] text-xs">
                  Reset all edits
                </Button>
              </>
            ) : (
              <Button size="sm" onClick={() => setLoginOpen(true)} className="font-['Open_Sans'] text-xs">
                Board login
              </Button>
            )}
          </div>
        </div>

        {error && (
          <div className="mb-6 p-4 bg-red-50 text-red-700 rounded-xl border border-red-100 text-sm font-['Open_Sans']">
            {error}
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {visibleDays.map((day) => {
            const display = effectiveDay(day);
            const isEditing = !!editingDays[day.day];
            const isDeleted = !!day.deleted;
            const images = allImages(display);
            const firstImage = primaryImage(display);

            return (
              <article
                key={day.day}
                className={`group bg-white rounded-xl shadow-sm border border-[#e5e2df] overflow-hidden flex flex-col hover:shadow-md transition-shadow ${
                  isDeleted ? 'opacity-60 grayscale' : ''
                }`}
              >
                <div
                  className={`px-4 py-2 flex items-center justify-between ${themeColors[day.type]} ${themeText[day.type]} font-['Montserrat']`}
                >
                  <span className="text-lg font-bold">Day {day.day}</span>
                  <span className="text-xs uppercase tracking-wide font-['Open_Sans'] font-semibold">
                    {day.theme}
                  </span>
                </div>

                <div className="px-4 py-2 bg-[#f8f6f4] flex items-center justify-between border-b border-[#e5e2df]">
                  {isDeleted ? (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => toggleDelete(day.day)}
                      className="font-['Open_Sans'] text-xs h-7 px-2"
                    >
                      Restore
                    </Button>
                  ) : (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => (isEditing ? cancelEdit(day.day) : startEdit(day))}
                      disabled={!boardToken}
                      className="font-['Open_Sans'] text-xs h-7 px-2"
                    >
                      {boardToken ? (isEditing ? 'Cancel' : 'Edit') : 'View only'}
                    </Button>
                  )}
                  <div className="flex items-center gap-2">
                    <Checkbox
                      id={`delete-${day.day}`}
                      checked={isDeleted}
                      onCheckedChange={() => toggleDelete(day.day)}
                      disabled={!boardToken}
                      aria-label="Delete"
                    />
                    <span
                      onClick={() => boardToken && toggleDelete(day.day)}
                      className={`text-xs font-['Open_Sans'] ${boardToken ? 'cursor-pointer' : 'text-gray-400'}`}
                    >
                      Delete
                    </span>
                  </div>
                </div>

                {!isDeleted && (
                  <div className="relative overflow-hidden bg-[#eef6ff] cursor-pointer">
                    <img
                      src={firstImage}
                      alt={`Day ${day.day} ${day.theme}`}
                      onClick={() => setSelected(day)}
                      className="w-full h-48 object-cover transition-transform duration-200 ease-out group-hover:scale-200"
                      loading="lazy"
                    />
                    {images.length > 1 && (
                      <div className="absolute top-2 right-2 bg-[#0a5ca4] text-white text-xs px-2 py-1 rounded-full flex items-center gap-1">
                        <Images className="w-3 h-3" />
                        {images.length}
                      </div>
                    )}
                  </div>
                )}

                <div className="p-4 flex flex-col gap-3 flex-1">
                  {isEditing ? (
                    <div className="flex flex-col gap-3">
                      <Textarea
                        value={draft[day.day]?.caption || ''}
                        onChange={(e) => updateDraft(day.day, { caption: e.target.value })}
                        rows={3}
                        className="text-sm font-['Open_Sans']"
                      />
                      <Textarea
                        value={draft[day.day]?.engagement || ''}
                        onChange={(e) => updateDraft(day.day, { engagement: e.target.value })}
                        rows={2}
                        className="text-sm font-['Open_Sans']"
                      />
                      <div className="flex flex-col gap-1">
                        <label className="text-xs font-semibold text-[#826c5f] font-['Open_Sans']">
                          Hashtags
                        </label>
                        <Textarea
                          value={formatHashtags(draft[day.day]?.hashtags || [])}
                          onChange={(e) => updateDraft(day.day, { hashtags: parseHashtags(e.target.value) })}
                          rows={2}
                          placeholder="#Hashtags separated by spaces or commas"
                          className="text-sm font-['Open_Sans']"
                        />
                      </div>
                      {renderImageEditor(day)}
                      <div className="flex gap-2">
                        <Button
                          type="button"
                          size="sm"
                          onClick={() => saveEdit(day.day)}
                          className="font-['Open_Sans'] text-xs"
                        >
                          Save
                        </Button>
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => cancelEdit(day.day)}
                          className="font-['Open_Sans'] text-xs"
                        >
                          Cancel
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <>
                      <p className="font-['Open_Sans'] text-[15px] leading-relaxed text-[#524644]">
                        {display.caption}
                      </p>

                      <p className="font-['Open_Sans'] text-sm font-semibold text-[#0a5ca4]">
                        {display.engagement}
                      </p>

                      <div className="mt-auto pt-2 flex flex-wrap gap-1">
                        {display.hashtags.map((tag, idx) => (
                          <span
                            key={`${day.day}-${tag}-${idx}`}
                            className="text-xs font-['Open_Sans'] text-[#826c5f] bg-[#f2eeeb] px-2 py-0.5 rounded-full"
                          >
                            #{tag}
                          </span>
                        ))}
                      </div>
                    </>
                  )}
                </div>
              </article>
            );
          })}
        </div>
      </section>

      <footer className="bg-[#0a5ca4] text-white py-8 px-6 text-center font-['Open_Sans'] text-sm">
        <p>Built for Kustom Imprints · Q3-2026 · PTA & school fundraiser content</p>
      </footer>

      <Dialog open={!!selected} onOpenChange={(open) => !open && setSelected(null)}>
        <DialogContent className="max-w-4xl p-0 overflow-hidden bg-white font-['Open_Sans']">
          {selected && (
            <>
              <DialogHeader
                className={`px-6 py-4 ${themeColors[selected.type]} ${themeText[selected.type]} font-['Montserrat']`}
              >
                <DialogTitle className="text-xl">Day {selected.day} · {selected.theme}</DialogTitle>
                <DialogDescription className={`${themeText[selected.type]} opacity-90`}>
                  Click the image or press Esc to close
                </DialogDescription>
              </DialogHeader>
              <div className="p-6 flex flex-col gap-4">
                {(() => {
                  const images = allImages(selected);
                  const isCarousel = images.length > 1;
                  return (
                    <div className="relative">
                      <img
                        src={images[modalIndex]}
                        alt={`Day ${selected.day} ${selected.theme} ${modalIndex + 1}/${images.length}`}
                        className="w-full max-h-[60vh] object-contain rounded-lg bg-[#eef6ff]"
                      />
                      {isCarousel && (
                        <>
                          <button
                            onClick={() => setModalIndex((i) => (i - 1 + images.length) % images.length)}
                            className="absolute left-2 top-1/2 -translate-y-1/2 bg-white/90 hover:bg-white text-[#524644] p-2 rounded-full shadow"
                          >
                            <ChevronLeft className="w-5 h-5" />
                          </button>
                          <button
                            onClick={() => setModalIndex((i) => (i + 1) % images.length)}
                            className="absolute right-2 top-1/2 -translate-y-1/2 bg-white/90 hover:bg-white text-[#524644] p-2 rounded-full shadow"
                          >
                            <ChevronRight className="w-5 h-5" />
                          </button>
                          <div className="flex justify-center gap-2 mt-3">
                            {images.map((_, idx) => (
                              <button
                                key={idx}
                                onClick={() => setModalIndex(idx)}
                                className={`w-2 h-2 rounded-full ${
                                  idx === modalIndex ? 'bg-[#0a5ca4]' : 'bg-[#cfcfcf]'
                                }`}
                              />
                            ))}
                          </div>
                        </>
                      )}
                    </div>
                  );
                })()}
                <p className="text-[15px] leading-relaxed text-[#524644]">{selected.caption}</p>
                <p className="text-sm font-semibold text-[#0a5ca4]">{selected.engagement}</p>
                <div className="flex flex-wrap gap-1">
                  {selected.hashtags.map((tag, idx) => (
                    <span
                      key={`${selected.day}-${tag}-${idx}`}
                      className="text-xs text-[#826c5f] bg-[#f2eeeb] px-2 py-0.5 rounded-full"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>

      <Dialog open={loginOpen} onOpenChange={setLoginOpen}>
        <DialogContent className="bg-white font-['Open_Sans'] max-w-sm">
          <DialogHeader>
            <DialogTitle className="font-['Montserrat']">Board login</DialogTitle>
            <DialogDescription>
              Enter the board passcode to edit or delete posts.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleLogin} className="flex flex-col gap-4 py-4">
            <Input
              type="password"
              value={tokenInput}
              onChange={(e) => setTokenInput(e.target.value)}
              placeholder="Board passcode"
              className="font-['Open_Sans']"
            />
            <div className="flex gap-2 justify-end">
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => setLoginOpen(false)}
                className="font-['Open_Sans'] text-xs"
              >
                Cancel
              </Button>
              <Button type="submit" size="sm" className="font-['Open_Sans'] text-xs">
                Login
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
