// 120-day Facebook social calendar for Kustom Imprints
// Strict repeating cycle: Product → Lifestyle → Carousel → Poll → Fundraiser → Clipart
//
// PLACEHOLDER APPAREL IMAGE MAPPING
// The 11 apparel product photos below are assigned to schools using the order
// shown in the current `apparelProducts` array. If you re-upload names or know
// exact filenames, edit the indices in the `organizations` array below.
//
// Default mapping:
//   CCYL Academy              → apparelProducts[0], [1]
//   HK                        → apparelProducts[2]
//   Gerstell Athletics        → apparelProducts[3]
//   San Pasqual Eagles        → apparelProducts[4], [5]
//   McMillin Beagles          → apparelProducts[6]
//   BroadwayMTC               → apparelProducts[7]
//   Life & Power              → apparelProducts[8], [9], [10]

export type PostType = 'product' | 'lifestyle' | 'carousel' | 'poll' | 'fundraiser' | 'clipart';

export interface CalendarDay {
  day: number;
  type: PostType;
  theme: string;
  image: string;
  images?: string[];
  caption: string;
  engagement: string;
  hashtags: string[];
  deleted?: boolean;
}

const BRAND_BASE = 'https://xbdjpgnswarigctphgzb.supabase.co/storage/v1/object/public/project-images/96c80e66-b8c7-44cf-af3c-7bf8137972e7/f1cd2e56-c5e9-46de-a568-59313d09a0c3/images';
const GEN_BASE = 'https://xbdjpgnswarigctphgzb.supabase.co/storage/v1/object/public/project-images/generated-images/f1cd2e56-c5e9-46de-a568-59313d09a0c3';

const newImages = {
  mcmillinFamily: `${BRAND_BASE}/chat_1786406497734_ah1hyxqovcv.png`,
  oxnardPanthersDW06: `${BRAND_BASE}/chat_1786406504090_55dscx0e1k.png`,
  canyonHillsDW03: `${BRAND_BASE}/chat_1786406510739_st0hjquqz18.png`,
  stanleyTigersDW04: `${BRAND_BASE}/chat_1786406518361_jxrtlmo9fr.png`,
};

const drinkwareImages = {
  collage: `${BRAND_BASE}/chat_1786405489418_lnhnk87p71.png`,
  windsarHills: `${BRAND_BASE}/chat_1786405501807_sn3qi6mvw8.png`,
  mayfield: `${BRAND_BASE}/chat_1786405475407_ko7849zhvk.png`,
  putnamCityWest: `${BRAND_BASE}/chat_1786405466362_d3wgv3nmwo.png`,
  pcnPanthers: `${BRAND_BASE}/chat_1786405454343_x2esqqkojtb.png`,
};

const apparelProducts = [
  `${BRAND_BASE}/chat_1786391895370_pvxe771lmr.png`,
  `${BRAND_BASE}/chat_1786391816903_fc7x67l2r5.png`,
  `${BRAND_BASE}/chat_1786391802848_vtgesxwjyt.png`,
  `${BRAND_BASE}/chat_1786391776593_hjcvc9j5cdj.png`,
  `${BRAND_BASE}/chat_1786391764846_tfcqrek3cqa.png`,
  `${BRAND_BASE}/chat_1786391755331_55cmvbz6zpb.png`,
  `${BRAND_BASE}/chat_1786391747342_klp6i7i7mq.png`,
  `${BRAND_BASE}/chat_1786391700297_ldo8251nfc.png`,
  `${BRAND_BASE}/chat_1786391682717_gyavwieqme.png`,
  `${BRAND_BASE}/chat_1786391674773_sxzu85rq2n.png`,
  `${BRAND_BASE}/chat_1786391690837_a14svhtxktb.png`,
];

const lifestylePhotos = [
  `${BRAND_BASE}/chat_1786389544003_ytn5b44ezuk.jpeg`,
  `${BRAND_BASE}/chat_1786389534160_0cr5jejlmm8.jpeg`,
  `${BRAND_BASE}/chat_1786389493621_jwiw49pglqf.jpeg`,
  `${BRAND_BASE}/chat_1786389484784_c4qym1e6icb.jpeg`,
  newImages.mcmillinFamily,
  `${BRAND_BASE}/chat_1786389064532_0gxwd2r2j8op.jpeg`,
  `${BRAND_BASE}/chat_1786389057933_lrb89vtvqf.jpeg`,
  `${BRAND_BASE}/chat_1786389017119_eoft3xyv0vo.jpeg`,
  `${BRAND_BASE}/chat_1786389011952_59lzxjlun8q.jpeg`,
  `${BRAND_BASE}/chat_1786389005651_a7hahsexvys.jpeg`,
  `${BRAND_BASE}/chat_1786389000013_6g96up1ec1j.jpeg`,
  `${BRAND_BASE}/chat_1786388982738_vgen936ym7.jpeg`,
  `${BRAND_BASE}/chat_1786388951832_lncwqrjz2wb.jpeg`,
  `${BRAND_BASE}/chat_1786388944985_zb8mgxxts2j.jpeg`,
  `${BRAND_BASE}/chat_1786388931512_md7btil6cj.jpeg`,
  `${GEN_BASE}/20260810_192820_Candid_lifestyle_pho_362b6450.webp`,
  `${GEN_BASE}/20260810_192817_School_carnival_life_2e777513.webp`,
  `${GEN_BASE}/20260810_192814_Golden_hour_lifestyl_cb4f07f1.webp`,
  `${GEN_BASE}/20260810_192814_Candid_wide_lifestyl_d9c34c80.webp`,
  `${GEN_BASE}/20260810_192814_Wide_lifestyle_photo_3ec209a4.webp`,
  `${GEN_BASE}/20260810_192813_School_fundraiser_li_3366cbb7.webp`,
  `${GEN_BASE}/20260810_192814_Morning_routine_life_97fb420e.webp`,
  `${GEN_BASE}/20260810_192813_Warm_lifestyle_photo_8e91d5e3.webp`,
  `${GEN_BASE}/20260810_192810_Close-up_lifestyle_p_9e8dda22.webp`,
  `${GEN_BASE}/20260810_192810_Group_lifestyle_port_f1df8a83.webp`,
  `${GEN_BASE}/20260810_192809_Friendly_lifestyle_s_d5312129.webp`,
  `${GEN_BASE}/20260810_192809_Creative_school_art__af691c4c.webp`,
  `${GEN_BASE}/20260810_192809_Warm_classroom_lifes_bda5e3c6.webp`,
  `${GEN_BASE}/20260810_192809_Lifestyle_photograph_d38bcf4e.webp`,
  `${GEN_BASE}/20260810_192809_Suburban_carpool_lif_9e05bf5f.webp`,
];

const clipartImages = [
  `${GEN_BASE}/20260810_184247_Flat_design_social_m_cd27c9d5.webp`,
  `${GEN_BASE}/20260810_184222_Flat_design_social_m_8ed378c0.webp`,
  `${GEN_BASE}/20260810_184205_Flat_design_social_m_beb37dc9.webp`,
  `${GEN_BASE}/20260810_184144_Flat_design_social_m_453e1aa7.webp`,
  `${GEN_BASE}/20260810_184127_Flat_design_social_m_49fbb490.webp`,
  `${GEN_BASE}/20260810_184111_Flat_design_social_m_a537ff8d.webp`,
  `${GEN_BASE}/20260810_184053_Flat_design_social_m_7bc91231.webp`,
  `${GEN_BASE}/20260810_184028_Flat_design_social_m_5fffbc63.webp`,
  `${GEN_BASE}/20260810_184009_Flat_design_social_m_d2d10feb.webp`,
  `${GEN_BASE}/20260810_183948_Flat_design_social_m_4bd205e5.webp`,
  `${GEN_BASE}/20260810_183933_Flat_design_social_m_3724060e.webp`,
  `${GEN_BASE}/20260810_183916_Flat_design_social_m_5163f147.webp`,
  `${GEN_BASE}/20260810_183859_Flat_design_social_m_407ee777.webp`,
  `${GEN_BASE}/20260810_183843_Flat_design_social_m_f1918f85.webp`,
  `${GEN_BASE}/20260810_183830_Flat_design_social_m_0e763c9b.webp`,
];

interface Org {
  name: string;
  hashtag: string;
  apparelImages?: string[];
  drinkwareImages?: string[];
}

const organizations: Org[] = [
  { name: 'CCYL Academy', hashtag: 'CCYLAcademy', apparelImages: [apparelProducts[0], apparelProducts[1]] },
  { name: 'HK', hashtag: 'HKSpirit', apparelImages: [apparelProducts[2]] },
  { name: 'Gerstell Athletics', hashtag: 'GerstellAthletics', apparelImages: [apparelProducts[3]] },
  { name: 'San Pasqual Eagles', hashtag: 'SanPasqualEagles', apparelImages: [apparelProducts[4], apparelProducts[5]] },
  { name: 'McMillin Beagles', hashtag: 'McMillinBeagles', apparelImages: [apparelProducts[6]] },
  { name: 'BroadwayMTC', hashtag: 'BroadwayMTC', apparelImages: [apparelProducts[7]] },
  { name: 'Life & Power', hashtag: 'LifeAndPower', apparelImages: [apparelProducts[8], apparelProducts[9], apparelProducts[10]] },
  { name: 'PCN Panthers', hashtag: 'PCNPanthers', drinkwareImages: [drinkwareImages.pcnPanthers] },
  { name: 'Putnam City West Wildcats', hashtag: 'PutnamCityWestWildcats', drinkwareImages: [drinkwareImages.putnamCityWest] },
  { name: 'Windsar Hills Elementary', hashtag: 'WindsarHillsElementary', drinkwareImages: [drinkwareImages.windsarHills] },
  { name: 'Mayfield Middle School Wildcats', hashtag: 'MayfieldWildcats', drinkwareImages: [drinkwareImages.mayfield] },
  { name: 'Oxnard High School Panthers', hashtag: 'OxnardPanthers', drinkwareImages: [newImages.oxnardPanthersDW06] },
  { name: 'Canyon Hills Volleyball', hashtag: 'CanyonHillsVolleyball', drinkwareImages: [newImages.canyonHillsDW03] },
  { name: 'Stanley Tigers', hashtag: 'StanleyTigers', drinkwareImages: [newImages.stanleyTigersDW04] },
];

const commonTags = ['KustomImprints', 'Fundraiser', 'PTA', 'ParentApproved'];

const apparelProductCaptions = [
  (org: string) => `${org} spirit wear is here—custom shirts made easy for your next fundraiser.`,
  (org: string) => `Fresh from the press: ${org} apparel your parents will actually want to buy.`,
  (org: string) => `Need a quick turnaround for ${org}? We've got parent-approved custom gear.`,
  (org: string) => `Quality that lasts all season—${org} custom apparel is ready to order.`,
  (org: string) => `Simple ordering, no hidden fees, happy ${org} volunteers.`,
  (org: string) => `Outfit the whole team: ${org} custom shirts without the design stress.`,
  (org: string) => `From mockup to mailbox—${org} gear shipped fast.`,
  (org: string) => `Soft, durable, and school-proud: ${org} custom apparel.`,
  (org: string) => `Raise more with less hassle. ${org} fundraising apparel starts here.`,
  (org: string) => `Custom looks for ${org} that won't blow the PTA budget.`,
];

const drinkwareProductCaptions = [
  (org: string) => `${org} laser-engraved drinkware is here—perfect for the next fundraiser.`,
  (org: string) => `Fresh from the laser: ${org} tumblers your parents will use every day.`,
  (org: string) => `Need a quick turnaround for ${org}? Parent-approved drinkware ships fast.`,
  (org: string) => `Quality that lasts all season—${org} custom drinkware is ready to order.`,
  (org: string) => `Simple ordering, no hidden fees, happy ${org} volunteers.`,
  (org: string) => `Outfit the whole team: ${org} laser-engraved tumblers without the stress.`,
  (org: string) => `From mockup to mailbox—${org} drinkware delivered fast.`,
  (org: string) => `Tough, stylish, and school-proud: ${org} custom drinkware.`,
  (org: string) => `Raise more with less hassle. ${org} fundraising drinkware starts here.`,
  (org: string) => `Custom looks for ${org} that won't blow the PTA budget.`,
];

const lifestyleCaptions = [
  (org: string) => `Spotted at the park: ${org} families repping custom spirit wear.`,
  (org: string) => `Nothing says community like matching ${org} shirts on a Saturday.`,
  (org: string) => `Real ${org} parents, real smiles, real school pride.`,
  (org: string) => `When the whole crew shows up in ${org} gear—game day ready.`,
  (org: string) => `Weekend vibes, ${org} pride. Custom apparel in the wild.`,
  (org: string) => `These ${org} families know: spirit wear is the best uniform.`,
  (org: string) => `From pickup line to picnic—${org} custom shirts go everywhere.`,
  (org: string) => `Community looks good on you, ${org}.`,
  (org: string) => `School spirit isn't a costume, it's a lifestyle. #${org}`,
  (org: string) => `Captured: ${org} parents making memories in custom gear.`,
];

const carouselCaptions = [
  (org: string) => `Swipe through ${org} favorites—tees, drinkware, and more for your next fundraiser.`,
  (org: string) => `One school, endless options. ${org} custom gear carousel.`,
  (org: string) => `Not sure what to sell? Here are ${org} parent-approved picks.`,
  (org: string) => `${org} fundraiser essentials: apparel + drinkware that sells out.`,
  (org: string) => `Build your ${org} bundle with our best sellers.`,
  (org: string) => `Carousel of ${org} ideas—because one post isn't enough.`,
  (org: string) => `Mix and match for ${org}: shirts, tumblers, and community pride.`,
  (org: string) => `Everything your ${org} fundraiser needs, in one swipe.`,
  (org: string) => `See what ${org} families are loving this season.`,
  (org: string) => `Top 4 ${org} custom items your PTA should stock.`,
];

const pollQuestions = [
  (org: string) => `Fall festival season is here—should ${org} sell custom shirts or laser-engraved drinkware?`,
  (org: string) => `Spring fundraiser crunch: what ${org} product would parents actually buy?`,
  (org: string) => `Teacher Appreciation Week is coming—would ${org} parents gift a custom tumbler?`,
  (org: string) => `Spirit wear sale season: which ${org} item are you pre-ordering first?`,
  (org: string) => `End-of-year graduation event: should ${org} offer custom apparel or drinkware?`,
  (org: string) => `For the next ${org} carnival booth: shirts, tumblers, or both?`,
  (org: string) => `When is the best time to launch a ${org} spirit wear sale?`,
  (org: string) => `What ${org} fundraiser item would you buy for yourself?`,
  (org: string) => `Which ${org} design theme would sell best this season?`,
  (org: string) => `PTA volunteers: what's the biggest blocker for your ${org} fundraiser?`,
];

const drinkwareFundraiserCaptions = [
  (org: string) => `This ${org} laser-engraved tumbler is the fundraiser item parents keep.`,
  (org: string) => `Raise more with less stress—${org} custom drinkware ships fast.`,
  (org: string) => `PTA moms love this: ${org} drinkware that actually sells.`,
  (org: string) => `Make your ${org} fundraiser the one everyone talks about.`,
  (org: string) => `High-quality, parent-approved, and ready for ${org}.`,
  (org: string) => `Fundraise smarter with ${org} custom drinkware.`,
  (org: string) => `The ${org} tumbler parents will use every day—and your school earns.`,
  (org: string) => `No design skills needed—we make ${org} fundraising simple.`,
  (org: string) => `Tired of low-profit fundraisers? Try ${org} custom drinkware.`,
  (org: string) => `${org} parents: the easiest fundraiser you'll ever run.`,
];

const apparelFundraiserCaptions = [
  (org: string) => `This ${org} custom apparel is the fundraiser item parents wear all year.`,
  (org: string) => `Raise more with less stress—${org} custom shirts ship fast.`,
  (org: string) => `PTA moms love this: ${org} spirit wear that actually sells.`,
  (org: string) => `Make your ${org} fundraiser the one everyone talks about.`,
  (org: string) => `High-quality, parent-approved, and ready for ${org}.`,
  (org: string) => `Fundraise smarter with ${org} custom apparel and drinkware.`,
  (org: string) => `The ${org} shirt parents grab first—and your school earns.`,
  (org: string) => `No design skills needed—we make ${org} fundraising simple.`,
  (org: string) => `Tired of low-profit fundraisers? Try ${org} custom apparel.`,
  (org: string) => `${org} parents: the easiest fundraiser you'll ever run.`,
];

const clipartCaptions = [
  (org: string) => `Clean, simple, and ${org} proud— clipart style for busy parents.`,
  (org: string) => `Bold ${org} colors, friendly message, zero clutter.`,
  (org: string) => `Quick reminder: ${org} orders are easier than you think.`,
  (org: string) => `Flat design, big impact. ${org} school spirit made simple.`,
  (org: string) => `When in doubt, keep it simple—${org} edition.`,
  (org: string) => `Clipart style tip: navy + #cfcfcf + one clear callout for ${org}.`,
  (org: string) => `No photo? No problem. ${org} clipart posts still stop the scroll.`,
  (org: string) => `Simple, on-brand, and ready for ${org} parents.`,
  (org: string) => `Less noise, more ${org} pride.`,
  (org: string) => `Graphic post for ${org}: easy to read, easy to share.`,
];

const engagementPrompts = [
  'Comment YES for details.',
  'Drop a 🙌 if your school needs this.',
  'Tag a PTA parent who should see this.',
  'Comment FUNDRAISER for a quote.',
  'Share this with your school volunteer crew.',
  'Comment DRINKWARE for details.',
  'Drop your school name in the comments.',
  'Tag a parent who lives in spirit wear.',
  'Comment READY to get started.',
  'Pin this for your next meeting.',
];

function pick<T>(arr: T[] | undefined, index: number): T | undefined {
  return arr && arr.length > 0 ? arr[index % arr.length] : undefined;
}

function pickMany<T>(arr: T[] | undefined, start: number, count: number): T[] {
  if (!arr || arr.length === 0) return [];
  const out: T[] = [];
  for (let i = 0; i < count; i++) {
    out.push(arr[(start + i) % arr.length]);
  }
  return out;
}

function uniqueTags(tags: string[]): string[] {
  return [...new Set(tags)];
}

function orgForDay(day: number): Org {
  return organizations[day % organizations.length];
}

function primaryImageForOrg(org: Org): string {
  return org.drinkwareImages?.[0] ?? org.apparelImages?.[0] ?? clipartImages[0];
}

function productImageForOrg(org: Org, index: number): string {
  // Drinkware orgs sell drinkware; apparel orgs sell apparel.
  if (org.drinkwareImages?.length) {
    return pick(org.drinkwareImages, index)!;
  }
  return pick(org.apparelImages, index)!;
}

function fundraiserImageForOrg(org: Org, index: number): string {
  if (org.drinkwareImages?.length) {
    return pick(org.drinkwareImages, index)!;
  }
  return pick(org.apparelImages, index)!;
}

function carouselImagesForOrg(org: Org, index: number): string[] {
  const own: string[] = [];
  if (org.apparelImages) own.push(...org.apparelImages);
  if (org.drinkwareImages) own.push(...org.drinkwareImages);
  const generic = [...lifestylePhotos, ...clipartImages];
  const selected = own.length > 0 ? pickMany(own, index, 4) : pickMany(generic, index, 4);
  // Pad to 4 images if the org has fewer than 4 of its own.
  if (selected.length < 4) {
    selected.push(...pickMany(generic, index + selected.length, 4 - selected.length));
  }
  return selected.slice(0, 4);
}

function buildCycle(type: PostType, index: number, org: Org): Partial<CalendarDay> {
  const orgTags = [org.hashtag];

  switch (type) {
    case 'product': {
      const i = index % apparelProductCaptions.length;
      const isDrinkware = !!org.drinkwareImages?.length;
      const captions = isDrinkware ? drinkwareProductCaptions : apparelProductCaptions;
      return {
        theme: isDrinkware ? 'Laser-Engraved Drinkware' : 'Product Spotlight',
        image: productImageForOrg(org, index),
        caption: captions[i](org.name),
        engagement: pick(engagementPrompts, index) || '',
        hashtags: uniqueTags([...orgTags, 'CustomApparel', 'SchoolSpirit', ...commonTags]),
      };
    }
    case 'lifestyle': {
      const i = index % lifestyleCaptions.length;
      return {
        theme: 'Lifestyle Scene',
        image: pick(lifestylePhotos, index) || '',
        caption: lifestyleCaptions[i](org.name),
        engagement: pick(engagementPrompts, index + 1) || '',
        hashtags: uniqueTags([...orgTags, 'Community', 'SchoolSpirit', ...commonTags]),
      };
    }
    case 'carousel': {
      const i = index % carouselCaptions.length;
      const images = carouselImagesForOrg(org, index);
      return {
        theme: 'Carousel',
        image: images[0] || '',
        images,
        caption: carouselCaptions[i](org.name),
        engagement: pick(engagementPrompts, index + 2) || '',
        hashtags: uniqueTags([...orgTags, 'LaserEngravedDrinkware', 'CustomApparel', 'SchoolSpirit', ...commonTags]),
      };
    }
    case 'poll': {
      const i = index % pollQuestions.length;
      return {
        theme: 'Poll',
        image: pick(lifestylePhotos, index + 30) || '',
        caption: pollQuestions[i](org.name),
        engagement: 'Vote in the comments!',
        hashtags: uniqueTags([...orgTags, 'ParentVoice', 'SchoolSpirit', ...commonTags]),
      };
    }
    case 'fundraiser': {
      const i = index % drinkwareFundraiserCaptions.length;
      const isDrinkware = !!org.drinkwareImages?.length;
      const captions = isDrinkware ? drinkwareFundraiserCaptions : apparelFundraiserCaptions;
      return {
        theme: 'Fundraiser CTA',
        image: fundraiserImageForOrg(org, index),
        caption: captions[i](org.name),
        engagement: pick(engagementPrompts, index + 3) || '',
        hashtags: uniqueTags([...orgTags, 'LaserEngravedDrinkware', 'SchoolSpirit', ...commonTags]),
      };
    }
    case 'clipart': {
      const i = index % clipartCaptions.length;
      return {
        theme: 'Clipart / Flat Design',
        image: pick(clipartImages, index) || '',
        caption: clipartCaptions[i](org.name),
        engagement: pick(engagementPrompts, index + 4) || '',
        hashtags: uniqueTags([...orgTags, 'SchoolSpirit', ...commonTags]),
      };
    }
  }
}

export function generateCalendar(): CalendarDay[] {
  const cycle: PostType[] = ['product', 'lifestyle', 'carousel', 'poll', 'fundraiser', 'clipart'];
  const days: CalendarDay[] = [];
  for (let i = 0; i < 120; i++) {
    const type = cycle[i % cycle.length];
    const org = orgForDay(i);
    const cycleData = buildCycle(type, i, org);
    days.push({
      day: i + 1,
      type,
      theme: cycleData.theme || type,
      image: cycleData.image || '',
      images: cycleData.images,
      caption: cycleData.caption || '',
      engagement: cycleData.engagement || '',
      hashtags: cycleData.hashtags || [],
    });
  }
  return days;
}

export const calendarDays = generateCalendar();
