import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://tetkzssgwtpekwgpsfha.supabase.co';
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'sb_publishable_gqJM8fXL54G5AjMbLo4XSg_FAjRzxJx';

export const supabase = createClient(supabaseUrl, supabaseKey);
