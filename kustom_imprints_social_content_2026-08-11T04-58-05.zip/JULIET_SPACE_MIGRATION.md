# Recreate the Kustom Imprints 75-Day Social Calendar on Juliet.space

This guide walks you through rebuilding the **Kustom Imprints 75-day social calendar** (Vite + React + Tailwind + Supabase + Vercel) on a **juliet.space** workspace instead of `agentic-dev.juliet.space`.

> **Assumption:** `juliet.space` has the same core project-import/build/deploy surface as the dev environment, just at the production URL. Where the UI might differ, those spots are flagged below.

---

## What you are recreating

A single-page React app that displays a 75-day Facebook content calendar for Kustom Imprints. It includes:

- A strict repeating post cycle: **Product → Lifestyle → Carousel → Poll → Fundraiser → Clipart**
- School-matched images, captions, and hashtags
- Hover-to-zoom thumbnails
- A full-size gallery modal with prev/next for carousel posts
- Board login with a shared passcode
- Inline editing of captions, engagement prompts, hashtags, and image overrides
- A global **Save all edits** button that writes changes to Supabase
- Delete/restore and deleted-visibility toggle

Live example: `https://kustom-imprints-calendar.vercel.app`

---

## 1. Start a new project on juliet.space

1. Go to **juliet.space** and sign in.
2. Create a new project/workspace.
3. Choose **Import from GitHub** (recommended) or **Upload ZIP**.

> If `juliet.space` does not support GitHub import and only supports a blank workspace, skip to Option B in step 2 and upload the ZIP.

---

## 2. Export the code from this workspace

### Option A — GitHub (recommended)

1. Create a new **empty** GitHub repository.
2. In this workspace terminal, run:

```bash
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
git add .
git commit -m "Kustom Imprints social calendar baseline"
git branch -M main
git push -u origin main
```

3. In the new juliet.space project, choose **Import from GitHub** and select the repo you just pushed.

### Option B — ZIP download

1. In this workspace, run:

```bash
zip -r kustom-calendar.zip . -x "node_modules/*" -x ".git/*"
```

2. Download `kustom-calendar.zip`.
3. In juliet.space, choose **Upload ZIP** and select the file.

---

## 3. Install dependencies and confirm the build

Once the project is imported into juliet.space:

```bash
bun install
bun run build
```

Expected result:

- A `dist/` folder is created.
- The build completes with **0 errors** (you may see React Router v7 future-flag warnings, which are harmless).

If `bun` is not available in juliet.space, use:

```bash
npm install
npm run build
```

The project is Vite-based, so `vercel.json` already tells Vercel to:

- Run `bun run build`
- Serve from `dist/`
- Handle SPA routes by falling back to `index.html`

---

## 4. Set environment variables

The app reads Supabase credentials from env vars. In juliet.space, find the environment variables panel (usually in project settings) and add:

```bash
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-public-key
```

> **Current fallback values** (defined in `src/lib/supabase.ts`) are the public anon key for the existing project. Replace them with your own credentials for a fresh juliet.space deployment.

To get the values from Supabase:

1. Open your Supabase project dashboard.
2. Go to **Project Settings → API**.
3. Copy **Project URL** → `VITE_SUPABASE_URL`.
4. Copy **`anon` public key** → `VITE_SUPABASE_ANON_KEY`.

You can also create a `.env.local` file in the project root:

```bash
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-public-key
```

---

## 5. Supabase setup

### Option A — Keep the existing Supabase project

If you reuse the current project (`tetkzssgwtpekwgpsfha.supabase.co`), no schema changes are needed. The migration has already been applied.

### Option B — New Supabase project

Create a new Supabase project, then run these three SQL files **in order** in the Supabase SQL Editor:

1. `supabase/migrations/202608110000_initial_schema.sql`
2. `supabase/migrations/202608110120_fix_reset_function.sql`
3. `supabase/migrations/202608110300_image_override_columns.sql`

Then set the board passcode:

```sql
UPDATE app_settings
SET value = 'kustom-pta-board-2026'
WHERE key = 'board_token';
```

Change the value to a passcode only your board should know.

### What the migrations do

- **Initial schema** creates the `calendar_overrides` table, `app_settings` table, RLS public-read policy, and the base `update_calendar_override` / `reset_all_calendar_overrides` functions.
- **Reset fix** adds `WHERE day IS NOT NULL` to the reset function so Supabase's safe-update mode allows the `DELETE`.
- **Image override columns** adds `image` and `images` fields and updates the function signature to accept them.

---

## 6. Deploy to Vercel

### Option A — GitHub + Vercel dashboard (recommended)

1. Push the repo to GitHub (step 2A).
2. In Vercel, create a new project and import the GitHub repo.
3. Add the same environment variables from step 4 in Vercel's project settings.
4. Deploy. Vercel will auto-detect Vite and use the `vercel.json` config.

### Option B — Vercel CLI

Install the Vercel CLI if needed:

```bash
npm i -g vercel
```

Run:

```bash
vercel login
vercel
```

Follow the prompts. When asked, link to a new project. The build will use `vercel.json`.

For production:

```bash
vercel --prod
```

### Option C — Manual `dist` upload

If GitHub/CLI are not available:

```bash
bun run build
```

Then drag the `dist/` folder into Vercel's "Deploy a directory" option.

---

## 7. Verify the live deployment

1. Open the deployed URL.
2. Click **Board login** and enter the board token (`kustom-pta-board-2026` by default).
3. Edit a single-image post, change its image URL, and click **Save all edits**.
4. Refresh the page — the new image should persist.
5. Edit a carousel post, add/remove images, save, and refresh.
6. Click a thumbnail to open the gallery modal. Use the arrows to navigate carousel images.

If persistence fails, check:

- Environment variables are set correctly.
- The three migrations were run in order.
- The board token in `app_settings` matches the one you entered.

---

## 8. Key differences: juliet.space vs agentic-dev.juliet.space

| Area | agentic-dev | juliet.space (assumed) |
|------|-------------|------------------------|
| Project URL | `agentic-dev.juliet.space/...` | `juliet.space/...` |
| Import flow | GitHub import or ZIP | Likely the same; look for **Import** or **Create from GitHub** |
| Env var panel | Project settings | Same location; may have a different label |
| Build command | `bun run build` | Same Vite build command |
| Output directory | `dist` | Same (`dist`) |
| Deploy target | Vercel or preview URL | Same; connect Vercel or use built-in preview |

> **Flagged assumptions:** If juliet.space has a different project creation flow, custom domain setup, or built-in deployment instead of Vercel, follow its native equivalent for the steps above. The core requirement is that the Vite build outputs `dist/` and the Supabase env vars are injected at build time.

---

## Quick reference

| Task | Command / File |
|------|----------------|
| Install dependencies | `bun install` or `npm install` |
| Build the app | `bun run build` |
| Start dev server | `bun dev` |
| Supabase initial schema | `supabase/migrations/202608110000_initial_schema.sql` |
| Supabase reset fix | `supabase/migrations/202608110120_fix_reset_function.sql` |
| Supabase image override | `supabase/migrations/202608110300_image_override_columns.sql` |
| Supabase client config | `src/lib/supabase.ts` |
| Calendar data & logic | `src/data/calendar.ts`, `src/pages/Calendar.tsx` |
| Vercel config | `vercel.json` |
| Default board token | `kustom-pta-board-2026` |

---

## Files to keep in sync between instances

- `src/data/calendar.ts` — the 75-day calendar generator, image pools, captions, and hashtags
- `src/pages/Calendar.tsx` — the board UI, inline editor, gallery modal, and save logic
- `src/lib/supabase.ts` — Supabase client config (reads env vars, falls back to hardcoded credentials)
- `supabase/migrations/` — must run in order on any new Supabase project
- `vercel.json` — Vercel/Vite SPA routing config

---

## Next recommended move

Once the juliet.space instance is live and verified, add the **"Get a Quote" CTA** on the calendar page to convert traffic into custom apparel fundraiser inquiries — directly tied to the Q3 North Star.
