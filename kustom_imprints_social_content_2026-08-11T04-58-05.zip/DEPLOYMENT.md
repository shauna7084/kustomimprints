# Kustom Imprints Social Calendar — Deployment Guide

This guide covers moving the project to a new instance and wiring it up to Vercel, Supabase, and Juliet.

---

## 1. Export the code from this workspace

### Option A — GitHub (recommended)

1. Create a new empty GitHub repository.
2. In this workspace, run:

```bash
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
git add .
git commit -m "Kustom Imprints social calendar baseline"
git branch -M main
git push -u origin main
```

3. In the new Juliet instance, choose **Import from GitHub** and select the repo.

### Option B — ZIP download

1. Use the workspace **Download as ZIP** option (or run `zip -r kustom-calendar.zip .` excluding `node_modules` and `.git`).
2. Upload the ZIP into the new Juliet project.

---

## 2. Set environment variables

The project reads Supabase credentials from environment variables. Create a `.env.local` file in the project root or set these in the Juliet/Vercel dashboard:

```bash
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-public-key
```

Fallback values are hardcoded in `src/lib/supabase.ts` for the current project, but you should replace them with your own credentials.

To get them in Supabase:
- Project Settings → API → Project URL
- Project Settings → API → `anon` public key

---

## 3. Supabase setup

### Using the same Supabase project

If you keep the existing Supabase project (`tetkzssgwtpekwgpsfha.supabase.co`), no schema changes are needed. The migration is already applied.

### Using a new Supabase project

Run these SQL files in order in the Supabase SQL Editor:

1. `supabase/migrations/202608110000_initial_schema.sql`
2. `supabase/migrations/202608110120_fix_reset_function.sql`
3. `supabase/migrations/202608110300_image_override_columns.sql`

Then set the board passcode:

```sql
UPDATE app_settings
SET value = 'kustom-pta-board-2026'
WHERE key = 'board_token';
```

Change the value to whatever only your board should know.

---

## 4. Vercel domains

### Keep the existing live site

The current production deployment is at:

```
https://kustom-imprints-calendar.vercel.app
```

If you want it served at `live.kustomimprints.vercel.com`:

1. Go to the Vercel dashboard → project `kustom-imprints-calendar`.
2. Settings → Domains.
3. Add `live.kustomimprints.vercel.com` as a custom domain.
4. Follow Vercel’s DNS instructions.

### Deploy a separate copy for Juliet

If Juliet does not auto-deploy for you, create a new Vercel project:

1. Import the GitHub repo or upload the `dist` folder manually.
2. Set the environment variables from section 2 in Vercel.
3. Deploy. The default project URL will be `https://your-project-name.vercel.app`.

---

## 5. Juliet.space deployment

1. Create a new project in your Juliet dashboard.
2. Import the repo or upload the ZIP.
3. Ensure dependencies are installed (`bun install` or `npm install`).
4. Set the environment variables from section 2 in the Juliet environment panel.
5. Run the build command: `bun run build`.
6. Point Juliet at the `dist` output directory if it asks for one.

If Juliet.space provides a preview URL, the calendar should load there. Board edits will sync to whichever Supabase project is configured.

---

## 6. Build and verify

```bash
bun install
bun run build
```

- Open the deployed URL.
- Click **Board login** and enter the board token.
- Edit a single-image post, change its image URL, and click **Save all edits**.
- Refresh the page — the change should persist.
- Edit a carousel post, add/remove images, save, and refresh.

If persistence fails, the Supabase migration was not run or the environment variables are wrong.

---

## 7. Files to keep in sync

- `src/data/calendar.ts` — org/image/copy mapping
- `src/pages/Calendar.tsx` — UI and editing logic
- `src/lib/supabase.ts` — Supabase client config (use env vars)
- `supabase/migrations/` — must run in order on any new Supabase project
- `vercel.json` — Vercel/Vite SPA routing config

---

## Quick reference

| Service | What to do |
|--------|------------|
| GitHub | Push the repo so Juliet/Vercel can import it. |
| Supabase | Copy URL + anon key; run migrations; set board token. |
| Vercel | Add env vars; set custom domain if needed; deploy. |
| Juliet | Import repo/ZIP; add env vars; build from `dist`. |
